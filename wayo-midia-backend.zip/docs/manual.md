# Documentação do Backend Analítico - Wayo Mídia

## Visão Geral

Este documento fornece instruções detalhadas sobre o backend analítico desenvolvido para a Wayo Mídia, incluindo sua arquitetura, funcionalidades, instruções de instalação e uso.

## Índice

1. [Arquitetura e Stack Tecnológica](#arquitetura-e-stack-tecnológica)
2. [Funcionalidades Implementadas](#funcionalidades-implementadas)
3. [Instalação e Configuração](#instalação-e-configuração)
4. [Integração com a Landing Page](#integração-com-a-landing-page)
5. [Painel Administrativo](#painel-administrativo)
6. [API Endpoints](#api-endpoints)
7. [Segurança e Permissões](#segurança-e-permissões)
8. [Manutenção e Suporte](#manutenção-e-suporte)

## Arquitetura e Stack Tecnológica

### Backend
- **Node.js com Express**: Framework para API RESTful
- **MongoDB**: Banco de dados NoSQL para armazenamento de dados analíticos e candidaturas
- **Mongoose**: ODM para modelagem de dados e validação
- **JWT**: Para autenticação e autorização segura
- **Nodemailer**: Para envio de notificações por e-mail

### Frontend do Painel Administrativo
- **HTML/CSS/JavaScript**: Interface de usuário interativa
- **Bootstrap 5**: Framework CSS para design responsivo
- **Chart.js**: Para visualização de dados em gráficos

### Integrações
- **Google Analytics API**: Para coleta e visualização de dados do GA
- **Facebook Graph API**: Para integração com Facebook Pixel

## Funcionalidades Implementadas

### Análises
- **Contagem de visitantes**: Rastreamento de visitantes únicos por período
- **Tempo de permanência**: Métricas de engajamento na página
- **Taxa de conversão**: Monitoramento de formulários preenchidos e enviados
- **Origem do tráfego**: Análise de fontes de tráfego (Instagram, Google, etc.)
- **Dispositivos**: Distribuição de acessos por tipo de dispositivo

### Painel Administrativo
- **Dashboard**: Visão geral das métricas principais
- **Gerenciamento de candidaturas**: Listagem, filtragem e atualização de status
- **Exportação de dados**: Exportação de candidaturas em formato CSV/Excel
- **Sistema de permissões**: Diferentes níveis de acesso (admin, analista, recrutador)

### Notificações
- **E-mails automáticos**: Notificações para novas candidaturas
- **Relatórios periódicos**: Opção para receber resumos diários ou semanais

## Instalação e Configuração

### Requisitos
- Node.js (v14+)
- MongoDB (v4+)
- NPM ou Yarn

### Passos para Instalação

1. **Clone o repositório**
   ```bash
   git clone https://github.com/wayomidia/backend-analitico.git
   cd backend-analitico
   ```

2. **Instale as dependências**
   ```bash
   npm install
   ```

3. **Configure as variáveis de ambiente**
   Crie um arquivo `.env` na raiz do projeto com base no `.env.example`:
   ```
   PORT=5000
   NODE_ENV=production
   MONGO_URI=sua_conexao_mongodb
   JWT_SECRET=seu_segredo_jwt
   JWT_EXPIRE=30d
   EMAIL_SERVICE=gmail
   EMAIL_USERNAME=seu_email@gmail.com
   EMAIL_PASSWORD=sua_senha_app
   EMAIL_FROM=noreply@wayomidia.com
   GOOGLE_ANALYTICS_VIEW_ID=seu_view_id
   FACEBOOK_APP_ID=seu_app_id
   FACEBOOK_APP_SECRET=seu_app_secret
   ```

4. **Inicie o servidor**
   ```bash
   npm start
   ```

## Integração com a Landing Page

Para integrar o backend analítico com a landing page existente, siga os passos abaixo:

1. **Adicione o script de analytics**
   Inclua o script `analytics-script.js` no final da sua página HTML, antes do fechamento da tag `</body>`:
   ```html
   <script src="https://seu-dominio.com/integration/analytics-script.js"></script>
   ```

2. **Inicialize o rastreamento**
   O script inicializará automaticamente o rastreamento quando a página for carregada.

3. **Integração com Google Analytics e Facebook Pixel**
   Adicione também o script de integrações externas:
   ```html
   <script src="https://seu-dominio.com/integration/external-integrations.js"></script>
   ```
   
   E configure os IDs corretos:
   ```javascript
   document.addEventListener('DOMContentLoaded', () => {
     // Inicializar Google Analytics (substitua pelo ID real)
     setupGoogleAnalytics('G-XXXXXXXXXX');
     
     // Inicializar Facebook Pixel (substitua pelo ID real)
     setupFacebookPixel('XXXXXXXXXXXXXXXXXX');
   });
   ```

## Painel Administrativo

O painel administrativo permite visualizar métricas, gerenciar candidaturas e configurar notificações.

### Acesso

1. Acesse o painel através da URL: `https://seu-dominio.com/admin`
2. Faça login com as credenciais fornecidas:
   - Email: admin@wayomidia.com
   - Senha: (fornecida separadamente)

### Funcionalidades do Painel

- **Dashboard**: Visualize métricas principais como visitantes, conversões e candidaturas
- **Candidatos**: Gerencie candidaturas, atualize status e exporte dados
- **Análises**: Acesse gráficos detalhados e relatórios personalizados
- **Configurações**: Gerencie seu perfil e preferências de notificação

## API Endpoints

### Autenticação
- `POST /api/v1/auth/register`: Registrar novo usuário
- `POST /api/v1/auth/login`: Login de usuário
- `GET /api/v1/auth/me`: Obter usuário atual
- `GET /api/v1/auth/logout`: Logout

### Analytics
- `POST /api/v1/analytics/event`: Registrar evento analítico
- `GET /api/v1/analytics/visitors`: Obter métricas de visitantes
- `GET /api/v1/analytics/conversions`: Obter métricas de conversão

### Candidatos
- `GET /api/v1/candidates`: Listar candidatos (com filtros e paginação)
- `GET /api/v1/candidates/:id`: Obter candidato específico
- `POST /api/v1/candidates`: Criar novo candidato
- `PUT /api/v1/candidates/:id`: Atualizar candidato
- `DELETE /api/v1/candidates/:id`: Excluir candidato
- `GET /api/v1/candidates/stats`: Obter estatísticas de candidaturas
- `GET /api/v1/candidates/export`: Exportar candidatos para CSV

## Segurança e Permissões

### Níveis de Acesso
- **Admin**: Acesso completo a todas as funcionalidades
- **Analista**: Acesso a métricas e relatórios, sem permissão para gerenciar usuários
- **Recrutador**: Acesso apenas ao gerenciamento de candidaturas

### Medidas de Segurança
- Autenticação JWT
- Proteção contra ataques de força bruta
- Sanitização de inputs
- HTTPS para todas as comunicações
- Senhas armazenadas com hash seguro (bcrypt)

## Manutenção e Suporte

### Backups
O sistema realiza backups automáticos diários do banco de dados. Os backups são armazenados por 30 dias.

### Monitoramento
O sistema inclui logs detalhados para facilitar a identificação e resolução de problemas.

### Suporte
Para suporte técnico, entre em contato através do email: suporte@wayomidia.com

---

© 2025 Wayo Mídia. Todos os direitos reservados.
