# Guia de Instalação e Uso - Backend Analítico Wayo Mídia

Este guia fornece instruções passo a passo para instalar, configurar e utilizar o backend analítico desenvolvido para a Wayo Mídia.

## Conteúdo do Pacote

O pacote do backend analítico contém:

1. **Código-fonte do backend**: Implementação completa em Node.js/Express
2. **Scripts de integração**: Para a landing page e ferramentas externas
3. **Painel administrativo**: Interface para visualização de métricas e gerenciamento
4. **Documentação**: Manual completo e guias de referência

## Instalação Rápida

### 1. Requisitos

- Node.js (v14+)
- MongoDB (v4+)
- NPM ou Yarn

### 2. Configuração do Backend

```bash
# Clonar o repositório
git clone https://github.com/wayomidia/backend-analitico.git
cd backend-analitico

# Instalar dependências
npm install

# Configurar variáveis de ambiente
cp .env.example .env
# Edite o arquivo .env com suas configurações

# Iniciar o servidor
npm start
```

### 3. Integração com a Landing Page

Adicione os seguintes scripts à sua landing page:

```html
<!-- Antes do fechamento da tag </body> -->
<script src="https://seu-dominio.com/integration/analytics-script.js"></script>
<script src="https://seu-dominio.com/integration/external-integrations.js"></script>
<script>
  document.addEventListener('DOMContentLoaded', () => {
    // Configurar Google Analytics e Facebook Pixel
    window.WayoExternalIntegrations.setupGoogleAnalytics('SEU-ID-GA');
    window.WayoExternalIntegrations.setupFacebookPixel('SEU-ID-PIXEL');
  });
</script>
```

### 4. Acesso ao Painel Administrativo

Acesse o painel em: `https://seu-dominio.com/admin`

Credenciais iniciais:
- Email: admin@wayomidia.com
- Senha: (fornecida separadamente)

## Primeiros Passos

### 1. Verificar Instalação

Após a instalação, verifique se o backend está funcionando corretamente:

```bash
# Testar a API
curl http://localhost:5000/api/v1/health
# Deve retornar: {"status":"ok"}
```

### 2. Criar Usuário Administrador

Se não existir um usuário administrador, crie um:

```bash
# Usando a API
curl -X POST http://localhost:5000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Admin","email":"admin@wayomidia.com","password":"senha-segura","role":"admin"}'
```

### 3. Verificar Coleta de Dados

Após integrar os scripts na landing page:

1. Acesse a landing page
2. Abra o console do navegador (F12)
3. Verifique se há mensagens de "Wayo Analytics inicializado"
4. Acesse o painel administrativo para confirmar que os dados estão sendo coletados

## Solução de Problemas

### Problemas Comuns

1. **Erro de conexão com MongoDB**
   - Verifique se o MongoDB está em execução
   - Confirme se a string de conexão no arquivo .env está correta

2. **Scripts de analytics não carregam**
   - Verifique se os caminhos dos scripts estão corretos
   - Confirme se o CORS está configurado corretamente no backend

3. **Dados não aparecem no painel**
   - Verifique os logs do servidor para erros
   - Confirme se os eventos estão sendo enviados corretamente

### Suporte

Para suporte técnico, entre em contato:
- Email: suporte@wayomidia.com
- Telefone: +244 923386045

## Próximos Passos

1. **Personalizar métricas**: Ajuste as métricas coletadas conforme suas necessidades
2. **Configurar notificações**: Personalize as notificações por email
3. **Integrar com outras ferramentas**: Adicione integrações com outras plataformas

---

© 2025 Wayo Mídia. Todos os direitos reservados.
