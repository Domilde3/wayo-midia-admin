# Backend Analítico - Wayo Mídia

## Visão Geral da Arquitetura

Este documento descreve a arquitetura e stack tecnológica escolhidas para o backend analítico da Wayo Mídia, com base nos requisitos coletados.

## Requisitos

### Análises
- Contagem de visitantes por período
- Tempo de permanência na página
- Taxa de conversão dos formulários
- Origem do tráfego (Instagram, Google, Facebook, etc.)

### Painel Administrativo
- Interface visual e intuitiva
- Gráficos e métricas em tempo real
- Sistema de permissões para diferentes níveis de usuários

### Integrações
- Google Analytics
- Facebook Pixel
- API personalizada para dados específicos

### Funcionalidades Adicionais
- Gerenciamento de candidaturas com filtros
- Exportação de dados em Excel
- Notificações por e-mail para novas inscrições

## Stack Tecnológica

### Backend
- **Node.js com Express**: Framework robusto e de alta performance para API RESTful
- **MongoDB**: Banco de dados NoSQL para armazenamento flexível de dados analíticos e candidaturas
- **Mongoose**: ODM para modelagem de dados e validação
- **JWT**: Para autenticação e autorização segura
- **Nodemailer**: Para envio de notificações por e-mail

### Frontend do Painel Administrativo
- **React**: Para construção de interface de usuário interativa e responsiva
- **Material-UI**: Biblioteca de componentes para design consistente
- **Chart.js**: Para visualização de dados em gráficos
- **React Query**: Para gerenciamento de estado e cache de dados

### Integrações
- **Google Analytics API**: Para coleta e visualização de dados do GA
- **Facebook Graph API**: Para integração com Facebook Pixel
- **Puppeteer**: Para rastreamento personalizado quando necessário

### DevOps
- **Docker**: Para containerização e facilidade de implantação
- **GitHub Actions**: Para CI/CD
- **Jest**: Para testes automatizados

## Arquitetura

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│  Landing Page   │────▶│  Analytics API  │────▶│  MongoDB        │
│  (React)        │     │  (Express)      │     │  Database       │
│                 │     │                 │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                               │  ▲
                               │  │
                               ▼  │
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│  Admin Panel    │◀───▶│  Admin API      │────▶│  Email Service  │
│  (React)        │     │  (Express)      │     │  (Nodemailer)   │
│                 │     │                 │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                               │  ▲
                               │  │
                               ▼  │
                        ┌─────────────────┐
                        │                 │
                        │  External APIs  │
                        │  (GA, FB, etc.) │
                        │                 │
                        └─────────────────┘
```

## Componentes Principais

### 1. Analytics API
- Coleta dados de visitantes, tempo de permanência, conversões
- Integra com Google Analytics e Facebook Pixel
- Fornece endpoints para consulta de métricas

### 2. Admin API
- Gerencia autenticação e autorização
- Processa e filtra dados de candidaturas
- Gerencia notificações por e-mail
- Controla permissões de usuários

### 3. Admin Panel
- Dashboard com visualizações gráficas
- Interface para gerenciamento de candidaturas
- Sistema de exportação de dados
- Configurações de notificações e integrações

### 4. Banco de Dados
- Armazena dados de usuários e permissões
- Mantém registros de candidaturas
- Armazena métricas personalizadas não disponíveis no GA

## Fluxo de Dados

1. **Coleta de Dados**:
   - Scripts de rastreamento na landing page enviam dados para o Analytics API
   - Google Analytics e Facebook Pixel coletam dados paralelamente
   - Formulários de candidatura enviam dados para o Admin API

2. **Processamento**:
   - Analytics API processa e agrega dados de visitantes
   - Admin API processa candidaturas e gerencia notificações
   - Dados são armazenados no MongoDB

3. **Visualização**:
   - Admin Panel consulta APIs para exibir métricas e gráficos
   - Dados são atualizados em tempo real ou sob demanda
   - Relatórios podem ser exportados em Excel

## Segurança

- Autenticação JWT para acesso ao painel administrativo
- Sistema de permissões baseado em funções (admin, analista, recrutador)
- HTTPS para todas as comunicações
- Sanitização de inputs para prevenir injeções
- Rate limiting para prevenir ataques de força bruta

## Escalabilidade

- Arquitetura modular permite escalar componentes independentemente
- Caching de dados frequentemente acessados
- Paginação para grandes conjuntos de dados
- Indexação eficiente no banco de dados

## Próximos Passos

1. Configuração do ambiente de desenvolvimento
2. Implementação da estrutura básica do backend
3. Desenvolvimento do painel administrativo
4. Integração com Google Analytics e Facebook Pixel
5. Implementação do sistema de notificações
6. Testes e validação
7. Implantação e documentação
