const mongoose = require('mongoose');

const CandidateSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Por favor, informe o nome do candidato'],
    trim: true
  },
  email: {
    type: String,
    required: [true, 'Por favor, informe o email do candidato'],
    match: [
      /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
      'Por favor, informe um email válido'
    ]
  },
  phone: {
    type: String,
    required: [true, 'Por favor, informe o telefone do candidato']
  },
  position: {
    type: String,
    required: [true, 'Por favor, informe a vaga pretendida'],
    enum: ['Departamento Comercial', 'Produção Gráfica']
  },
  status: {
    type: String,
    enum: ['Recebido', 'Em análise', 'Entrevista agendada', 'Aprovado', 'Reprovado'],
    default: 'Recebido'
  },
  resume: {
    type: String, // URL para o currículo ou portfólio
  },
  notes: {
    type: String
  },
  source: {
    type: String,
    enum: ['Landing Page', 'Instagram', 'Indicação', 'Outro'],
    default: 'Landing Page'
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Atualizar o timestamp quando o documento for modificado
CandidateSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Candidate', CandidateSchema);
