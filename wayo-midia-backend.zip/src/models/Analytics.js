const mongoose = require('mongoose');

const AnalyticsSchema = new mongoose.Schema({
  pageUrl: {
    type: String,
    required: true,
    trim: true
  },
  visitorId: {
    type: String,
    required: true
  },
  sessionId: {
    type: String,
    required: true
  },
  userAgent: {
    type: String
  },
  ipAddress: {
    type: String
  },
  referrer: {
    type: String
  },
  eventType: {
    type: String,
    enum: ['pageview', 'click', 'form_start', 'form_submit', 'time_spent'],
    required: true
  },
  eventData: {
    type: mongoose.Schema.Types.Mixed
  },
  device: {
    type: String,
    enum: ['desktop', 'mobile', 'tablet'],
    required: true
  },
  browser: {
    type: String
  },
  os: {
    type: String
  },
  country: {
    type: String
  },
  city: {
    type: String
  },
  timestamp: {
    type: Date,
    default: Date.now
  }
});

// Índices para consultas frequentes
AnalyticsSchema.index({ timestamp: -1 });
AnalyticsSchema.index({ eventType: 1 });
AnalyticsSchema.index({ visitorId: 1 });
AnalyticsSchema.index({ pageUrl: 1 });

module.exports = mongoose.model('Analytics', AnalyticsSchema);
