const asyncHandler = require('../middleware/async');
const ErrorResponse = require('../utils/errorResponse');
const Analytics = require('../models/Analytics');

// @desc    Registrar evento analítico
// @route   POST /api/v1/analytics/event
// @access  Public
exports.recordEvent = asyncHandler(async (req, res, next) => {
  // Extrair dados do request
  const {
    pageUrl,
    visitorId,
    sessionId,
    eventType,
    eventData,
    device,
    referrer
  } = req.body;

  // Extrair informações do user agent
  const userAgent = req.headers['user-agent'];
  
  // Extrair IP (considerando possíveis proxies)
  const ipAddress = 
    req.headers['x-forwarded-for'] || 
    req.connection.remoteAddress;

  // Criar registro analítico
  const analytics = await Analytics.create({
    pageUrl,
    visitorId,
    sessionId,
    userAgent,
    ipAddress,
    referrer,
    eventType,
    eventData,
    device,
    browser: getBrowserInfo(userAgent),
    os: getOSInfo(userAgent),
    timestamp: new Date()
  });

  res.status(201).json({
    success: true,
    data: analytics
  });
});

// @desc    Obter métricas de visitantes
// @route   GET /api/v1/analytics/visitors
// @access  Private
exports.getVisitorMetrics = asyncHandler(async (req, res, next) => {
  // Extrair parâmetros de consulta
  const { startDate, endDate } = req.query;
  
  // Construir filtro de data
  const dateFilter = {};
  if (startDate) {
    dateFilter.$gte = new Date(startDate);
  }
  if (endDate) {
    dateFilter.$lte = new Date(endDate);
  }
  
  // Consulta para contar visitantes únicos
  const uniqueVisitors = await Analytics.distinct('visitorId', {
    ...(Object.keys(dateFilter).length > 0 && { timestamp: dateFilter })
  }).countDocuments();
  
  // Consulta para contar pageviews
  const pageviews = await Analytics.countDocuments({
    eventType: 'pageview',
    ...(Object.keys(dateFilter).length > 0 && { timestamp: dateFilter })
  });
  
  // Consulta para distribuição de dispositivos
  const deviceDistribution = await Analytics.aggregate([
    {
      $match: {
        ...(Object.keys(dateFilter).length > 0 && { timestamp: dateFilter })
      }
    },
    {
      $group: {
        _id: '$device',
        count: { $sum: 1 }
      }
    }
  ]);
  
  // Consulta para fontes de tráfego
  const trafficSources = await Analytics.aggregate([
    {
      $match: {
        ...(Object.keys(dateFilter).length > 0 && { timestamp: dateFilter })
      }
    },
    {
      $group: {
        _id: '$referrer',
        count: { $sum: 1 }
      }
    },
    {
      $sort: { count: -1 }
    },
    {
      $limit: 10
    }
  ]);

  res.status(200).json({
    success: true,
    data: {
      uniqueVisitors,
      pageviews,
      deviceDistribution,
      trafficSources
    }
  });
});

// @desc    Obter métricas de conversão
// @route   GET /api/v1/analytics/conversions
// @access  Private
exports.getConversionMetrics = asyncHandler(async (req, res, next) => {
  // Extrair parâmetros de consulta
  const { startDate, endDate } = req.query;
  
  // Construir filtro de data
  const dateFilter = {};
  if (startDate) {
    dateFilter.$gte = new Date(startDate);
  }
  if (endDate) {
    dateFilter.$lte = new Date(endDate);
  }
  
  // Consulta para contar formulários iniciados
  const formStarts = await Analytics.countDocuments({
    eventType: 'form_start',
    ...(Object.keys(dateFilter).length > 0 && { timestamp: dateFilter })
  });
  
  // Consulta para contar formulários enviados
  const formSubmissions = await Analytics.countDocuments({
    eventType: 'form_submit',
    ...(Object.keys(dateFilter).length > 0 && { timestamp: dateFilter })
  });
  
  // Calcular taxa de conversão
  const conversionRate = formStarts > 0 
    ? (formSubmissions / formStarts) * 100 
    : 0;
  
  // Consulta para conversões por vaga
  const conversionsByPosition = await Analytics.aggregate([
    {
      $match: {
        eventType: 'form_submit',
        ...(Object.keys(dateFilter).length > 0 && { timestamp: dateFilter })
      }
    },
    {
      $group: {
        _id: '$eventData.position',
        count: { $sum: 1 }
      }
    }
  ]);

  res.status(200).json({
    success: true,
    data: {
      formStarts,
      formSubmissions,
      conversionRate,
      conversionsByPosition
    }
  });
});

// Funções auxiliares para extrair informações do user agent
function getBrowserInfo(userAgent) {
  // Implementação simplificada - em produção usar biblioteca como ua-parser-js
  if (userAgent.includes('Chrome')) return 'Chrome';
  if (userAgent.includes('Firefox')) return 'Firefox';
  if (userAgent.includes('Safari')) return 'Safari';
  if (userAgent.includes('Edge')) return 'Edge';
  if (userAgent.includes('MSIE') || userAgent.includes('Trident/')) return 'Internet Explorer';
  return 'Outro';
}

function getOSInfo(userAgent) {
  // Implementação simplificada - em produção usar biblioteca como ua-parser-js
  if (userAgent.includes('Windows')) return 'Windows';
  if (userAgent.includes('Mac OS')) return 'MacOS';
  if (userAgent.includes('Linux')) return 'Linux';
  if (userAgent.includes('Android')) return 'Android';
  if (userAgent.includes('iOS')) return 'iOS';
  return 'Outro';
}
