const asyncHandler = require('../middleware/async');
const ErrorResponse = require('../utils/errorResponse');
const Candidate = require('../models/Candidate');
const sendEmail = require('../utils/sendEmail');

// @desc    Obter todos os candidatos
// @route   GET /api/v1/candidates
// @access  Private
exports.getCandidates = asyncHandler(async (req, res, next) => {
  res.status(200).json(res.advancedResults);
});

// @desc    Obter um candidato específico
// @route   GET /api/v1/candidates/:id
// @access  Private
exports.getCandidate = asyncHandler(async (req, res, next) => {
  const candidate = await Candidate.findById(req.params.id);

  if (!candidate) {
    return next(
      new ErrorResponse(`Candidato não encontrado com id ${req.params.id}`, 404)
    );
  }

  res.status(200).json({
    success: true,
    data: candidate
  });
});

// @desc    Criar novo candidato
// @route   POST /api/v1/candidates
// @access  Public
exports.createCandidate = asyncHandler(async (req, res, next) => {
  const candidate = await Candidate.create(req.body);

  // Enviar email de notificação
  try {
    await sendEmail({
      email: process.env.EMAIL_FROM,
      subject: `Nova candidatura recebida - ${req.body.position}`,
      message: `
        Uma nova candidatura foi recebida:
        
        Nome: ${req.body.name}
        Email: ${req.body.email}
        Telefone: ${req.body.phone}
        Vaga: ${req.body.position}
        
        Acesse o painel administrativo para mais detalhes.
      `
    });
  } catch (err) {
    console.log('Erro ao enviar email de notificação', err);
    // Não interromper o fluxo se o email falhar
  }

  res.status(201).json({
    success: true,
    data: candidate
  });
});

// @desc    Atualizar candidato
// @route   PUT /api/v1/candidates/:id
// @access  Private
exports.updateCandidate = asyncHandler(async (req, res, next) => {
  let candidate = await Candidate.findById(req.params.id);

  if (!candidate) {
    return next(
      new ErrorResponse(`Candidato não encontrado com id ${req.params.id}`, 404)
    );
  }

  candidate = await Candidate.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: candidate
  });
});

// @desc    Excluir candidato
// @route   DELETE /api/v1/candidates/:id
// @access  Private
exports.deleteCandidate = asyncHandler(async (req, res, next) => {
  const candidate = await Candidate.findById(req.params.id);

  if (!candidate) {
    return next(
      new ErrorResponse(`Candidato não encontrado com id ${req.params.id}`, 404)
    );
  }

  await candidate.remove();

  res.status(200).json({
    success: true,
    data: {}
  });
});

// @desc    Obter estatísticas de candidaturas
// @route   GET /api/v1/candidates/stats
// @access  Private
exports.getCandidateStats = asyncHandler(async (req, res, next) => {
  // Estatísticas por vaga
  const statsByPosition = await Candidate.aggregate([
    {
      $group: {
        _id: '$position',
        count: { $sum: 1 }
      }
    }
  ]);

  // Estatísticas por status
  const statsByStatus = await Candidate.aggregate([
    {
      $group: {
        _id: '$status',
        count: { $sum: 1 }
      }
    }
  ]);

  // Estatísticas por fonte
  const statsBySource = await Candidate.aggregate([
    {
      $group: {
        _id: '$source',
        count: { $sum: 1 }
      }
    }
  ]);

  // Estatísticas por data (últimos 30 dias)
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  const statsByDate = await Candidate.aggregate([
    {
      $match: {
        createdAt: { $gte: thirtyDaysAgo }
      }
    },
    {
      $group: {
        _id: {
          $dateToString: { format: '%Y-%m-%d', date: '$createdAt' }
        },
        count: { $sum: 1 }
      }
    },
    {
      $sort: { _id: 1 }
    }
  ]);

  res.status(200).json({
    success: true,
    data: {
      statsByPosition,
      statsByStatus,
      statsBySource,
      statsByDate
    }
  });
});

// @desc    Exportar candidatos para Excel
// @route   GET /api/v1/candidates/export
// @access  Private
exports.exportCandidates = asyncHandler(async (req, res, next) => {
  // Implementação básica - em produção usar biblioteca como exceljs
  const candidates = await Candidate.find();
  
  // Converter para CSV
  let csv = 'Nome,Email,Telefone,Vaga,Status,Data de Candidatura\n';
  
  candidates.forEach(candidate => {
    csv += `${candidate.name},${candidate.email},${candidate.phone},${candidate.position},${candidate.status},${candidate.createdAt}\n`;
  });
  
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename=candidatos.csv');
  
  res.status(200).send(csv);
});
