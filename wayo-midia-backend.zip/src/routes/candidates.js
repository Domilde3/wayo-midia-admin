const express = require('express');
const {
  getCandidates,
  getCandidate,
  createCandidate,
  updateCandidate,
  deleteCandidate,
  getCandidateStats,
  exportCandidates
} = require('../controllers/candidates');

const Candidate = require('../models/Candidate');
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// Aplicar proteção a todas as rotas exceto createCandidate
router.use(protect).use(authorize('admin', 'recrutador')).route('/stats').get(getCandidateStats);
router.use(protect).use(authorize('admin', 'recrutador')).route('/export').get(exportCandidates);

// Rota pública para criação de candidatos
router.route('/').post(createCandidate);

// Rotas protegidas
router
  .route('/')
  .get(advancedResults(Candidate), getCandidates);

router
  .route('/:id')
  .get(getCandidate)
  .put(updateCandidate)
  .delete(authorize('admin'), deleteCandidate);

module.exports = router;
