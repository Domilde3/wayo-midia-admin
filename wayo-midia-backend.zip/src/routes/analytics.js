const express = require('express');
const {
  recordEvent,
  getVisitorMetrics,
  getConversionMetrics
} = require('../controllers/analytics');

const router = express.Router();

const { protect, authorize } = require('../middleware/auth');

// Rota pública para registrar eventos
router.post('/event', recordEvent);

// Rotas protegidas para obter métricas
router.get('/visitors', protect, authorize('admin', 'analista'), getVisitorMetrics);
router.get('/conversions', protect, authorize('admin', 'analista'), getConversionMetrics);

module.exports = router;
