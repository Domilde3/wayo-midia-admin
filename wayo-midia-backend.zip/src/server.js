const express = require('express');
const dotenv = require('dotenv');
const morgan = require('morgan');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const errorHandler = require('./middleware/error');
const connectDB = require('./config/database');

// Carregar variáveis de ambiente
dotenv.config();

// Conectar ao banco de dados
connectDB();

// Importar rotas
const auth = require('./routes/auth');
const analytics = require('./routes/analytics');
const candidates = require('./routes/candidates');

const app = express();

// Body parser
app.use(express.json());

// Middleware de segurança
app.use(helmet());

// Habilitar CORS
app.use(cors());

// Rate limiting
const limiter = rateLimit({
  windowMs: 10 * 60 * 1000, // 10 minutos
  max: 100 // limite de 100 requisições por janela
});
app.use(limiter);

// Logging em desenvolvimento
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// Montar rotas
app.use('/api/v1/auth', auth);
app.use('/api/v1/analytics', analytics);
app.use('/api/v1/candidates', candidates);

// Middleware de tratamento de erros
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

const server = app.listen(
  PORT,
  console.log(`Servidor rodando em modo ${process.env.NODE_ENV} na porta ${PORT}`)
);

// Tratamento de rejeições não tratadas
process.on('unhandledRejection', (err, promise) => {
  console.log(`Erro: ${err.message}`);
  // Fechar servidor e sair do processo
  server.close(() => process.exit(1));
});
