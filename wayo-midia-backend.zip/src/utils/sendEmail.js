const nodemailer = require('nodemailer');

const sendEmail = async (options) => {
  // Criar um transporter reutilizável usando SMTP
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: process.env.SMTP_PORT || 587,
    secure: process.env.SMTP_SECURE === 'true', // true para 465, false para outras portas
    auth: {
      user: process.env.EMAIL_USERNAME,
      pass: process.env.EMAIL_PASSWORD,
    },
  });

  // Definir opções de email
  const mailOptions = {
    from: `${process.env.FROM_NAME || 'Wayo Mídia'} <${process.env.EMAIL_FROM}>`,
    to: options.email,
    subject: options.subject,
    text: options.message,
    html: options.html,
  };

  // Enviar email
  const info = await transporter.sendMail(mailOptions);

  console.log(`Email enviado: ${info.messageId}`);
};

module.exports = sendEmail;
