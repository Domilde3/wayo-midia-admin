const asyncHandler = require('./async');

// Middleware para resultados avançados (paginação, filtragem, ordenação)
const advancedResults = (model, populate) => asyncHandler(async (req, res, next) => {
  let query;

  // Copiar req.query
  const reqQuery = { ...req.query };

  // Campos para excluir
  const removeFields = ['select', 'sort', 'page', 'limit'];

  // Remover campos excluídos de reqQuery
  removeFields.forEach(param => delete reqQuery[param]);

  // Criar string de consulta
  let queryStr = JSON.stringify(reqQuery);

  // Criar operadores ($gt, $gte, etc)
  queryStr = queryStr.replace(/\b(gt|gte|lt|lte|in)\b/g, match => `$${match}`);

  // Encontrar recursos
  query = model.find(JSON.parse(queryStr));

  // Select Fields
  if (req.query.select) {
    const fields = req.query.select.split(',').join(' ');
    query = query.select(fields);
  }

  // Sort
  if (req.query.sort) {
    const sortBy = req.query.sort.split(',').join(' ');
    query = query.sort(sortBy);
  } else {
    query = query.sort('-createdAt');
  }

  // Paginação
  const page = parseInt(req.query.page, 10) || 1;
  const limit = parseInt(req.query.limit, 10) || 25;
  const startIndex = (page - 1) * limit;
  const endIndex = page * limit;
  const total = await model.countDocuments(JSON.parse(queryStr));

  query = query.skip(startIndex).limit(limit);

  if (populate) {
    query = query.populate(populate);
  }

  // Executar consulta
  const results = await query;

  // Objeto de paginação
  const pagination = {};

  if (endIndex < total) {
    pagination.next = {
      page: page + 1,
      limit
    };
  }

  if (startIndex > 0) {
    pagination.prev = {
      page: page - 1,
      limit
    };
  }

  res.advancedResults = {
    success: true,
    count: results.length,
    pagination,
    data: results
  };

  next();
});

module.exports = advancedResults;
