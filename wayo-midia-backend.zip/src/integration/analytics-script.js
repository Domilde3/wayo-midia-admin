// Script para integração da landing page com o backend analítico
// Este script deve ser incluído na landing page para capturar eventos e enviar ao backend

// Configuração inicial
const ANALYTICS_API_URL = 'http://localhost:5000/api/v1/analytics/event';
const CANDIDATE_API_URL = 'http://localhost:5000/api/v1/candidates';

// Gerar ID único para o visitante (persistente entre sessões)
function generateVisitorId() {
  let visitorId = localStorage.getItem('wayo_visitor_id');
  if (!visitorId) {
    visitorId = 'v_' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    localStorage.setItem('wayo_visitor_id', visitorId);
  }
  return visitorId;
}

// Gerar ID de sessão (novo a cada visita)
function generateSessionId() {
  return 's_' + Math.random().toString(36).substring(2, 15) + Date.now();
}

// Detectar tipo de dispositivo
function getDeviceType() {
  const userAgent = navigator.userAgent;
  if (/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i.test(userAgent)) {
    return 'tablet';
  }
  if (/Mobile|Android|iP(hone|od)|IEMobile|BlackBerry|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(userAgent)) {
    return 'mobile';
  }
  return 'desktop';
}

// Classe principal de Analytics
class WayoAnalytics {
  constructor() {
    this.visitorId = generateVisitorId();
    this.sessionId = generateSessionId();
    this.device = getDeviceType();
    this.pageUrl = window.location.href;
    this.referrer = document.referrer;
    
    // Inicializar rastreamento
    this.initTracking();
  }

  // Inicializar rastreamento de eventos
  initTracking() {
    // Registrar pageview
    this.trackEvent('pageview');
    
    // Rastrear tempo na página
    this.startTimeTracking();
    
    // Rastrear cliques nos botões de candidatura
    this.trackCandidatureButtons();
    
    // Rastrear início de preenchimento de formulário
    this.trackFormInteractions();
  }

  // Enviar evento para o backend
  async trackEvent(eventType, eventData = {}) {
    try {
      const response = await fetch(ANALYTICS_API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          visitorId: this.visitorId,
          sessionId: this.sessionId,
          pageUrl: this.pageUrl,
          referrer: this.referrer,
          eventType,
          eventData,
          device: this.device,
          timestamp: new Date().toISOString()
        }),
      });
      
      if (!response.ok) {
        console.error('Erro ao enviar evento analítico:', await response.text());
      }
    } catch (error) {
      console.error('Erro ao enviar evento analítico:', error);
    }
  }

  // Rastrear tempo na página
  startTimeTracking() {
    const startTime = Date.now();
    
    // Enviar tempo ao sair da página
    window.addEventListener('beforeunload', () => {
      const timeSpent = Math.round((Date.now() - startTime) / 1000);
      this.trackEvent('time_spent', { seconds: timeSpent });
    });
    
    // Também enviar a cada 5 minutos para sessões longas
    setInterval(() => {
      const timeSpent = Math.round((Date.now() - startTime) / 1000);
      this.trackEvent('time_spent', { seconds: timeSpent, stillActive: true });
    }, 5 * 60 * 1000);
  }

  // Rastrear cliques nos botões de candidatura
  trackCandidatureButtons() {
    document.querySelectorAll('a[href*="docs.google.com/forms"]').forEach(button => {
      button.addEventListener('click', (e) => {
        // Identificar qual vaga foi clicada
        const position = button.closest('.bg-black') ? 
          button.closest('.bg-black').querySelector('h3').textContent.trim() : 
          'Não identificada';
        
        this.trackEvent('click', { 
          element: 'candidature_button',
          position
        });
      });
    });
  }

  // Rastrear interações com formulários
  trackFormInteractions() {
    // Como os formulários estão no Google Forms, rastreamos apenas os cliques nos links
    document.querySelectorAll('a[href*="docs.google.com/forms"]').forEach(formLink => {
      formLink.addEventListener('click', (e) => {
        const position = formLink.closest('.bg-black') ? 
          formLink.closest('.bg-black').querySelector('h3').textContent.trim() : 
          'Não identificada';
        
        this.trackEvent('form_start', { position });
      });
    });
  }

  // Método para registrar submissão de candidatura (chamado externamente)
  registerCandidature(candidateData) {
    // Enviar dados do candidato para o backend
    fetch(CANDIDATE_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ...candidateData,
        source: this.referrer || 'Landing Page'
      }),
    })
    .then(response => {
      if (response.ok) {
        // Registrar evento de conversão
        this.trackEvent('form_submit', { 
          position: candidateData.position,
          success: true 
        });
        return response.json();
      } else {
        throw new Error('Erro ao enviar candidatura');
      }
    })
    .catch(error => {
      console.error('Erro ao registrar candidatura:', error);
      this.trackEvent('form_submit', { 
        position: candidateData.position,
        success: false,
        error: error.message
      });
    });
  }
}

// Inicializar analytics quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
  window.wayoAnalytics = new WayoAnalytics();
  console.log('Wayo Analytics inicializado');
});

// Exportar para uso global
window.WayoAnalytics = WayoAnalytics;
