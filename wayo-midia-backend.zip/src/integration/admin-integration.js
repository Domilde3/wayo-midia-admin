// Script para integração do painel administrativo com o backend analítico
// Este arquivo contém as funções para consumir os endpoints do backend e exibir os dados no painel

// Configuração inicial
const API_BASE_URL = 'http://localhost:5000/api/v1';

// Classe para gerenciar autenticação
class AuthService {
  // Fazer login e obter token
  static async login(email, password) {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });
      
      const data = await response.json();
      
      if (response.ok) {
        // Armazenar token no localStorage
        localStorage.setItem('wayo_admin_token', data.token);
        return data;
      } else {
        throw new Error(data.error || 'Falha na autenticação');
      }
    } catch (error) {
      console.error('Erro de login:', error);
      throw error;
    }
  }
  
  // Verificar se o usuário está autenticado
  static isAuthenticated() {
    return localStorage.getItem('wayo_admin_token') !== null;
  }
  
  // Obter token atual
  static getToken() {
    return localStorage.getItem('wayo_admin_token');
  }
  
  // Fazer logout
  static logout() {
    localStorage.removeItem('wayo_admin_token');
    window.location.href = '/login';
  }
  
  // Obter informações do usuário atual
  static async getCurrentUser() {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/me`, {
        headers: {
          'Authorization': `Bearer ${this.getToken()}`
        }
      });
      
      const data = await response.json();
      
      if (response.ok) {
        return data.data;
      } else {
        throw new Error(data.error || 'Falha ao obter dados do usuário');
      }
    } catch (error) {
      console.error('Erro ao obter usuário atual:', error);
      throw error;
    }
  }
}

// Classe para gerenciar dados analíticos
class AnalyticsService {
  // Obter métricas de visitantes
  static async getVisitorMetrics(startDate, endDate) {
    try {
      let url = `${API_BASE_URL}/analytics/visitors`;
      
      // Adicionar parâmetros de data se fornecidos
      if (startDate || endDate) {
        url += '?';
        if (startDate) url += `startDate=${startDate}`;
        if (startDate && endDate) url += '&';
        if (endDate) url += `endDate=${endDate}`;
      }
      
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${AuthService.getToken()}`
        }
      });
      
      const data = await response.json();
      
      if (response.ok) {
        return data.data;
      } else {
        throw new Error(data.error || 'Falha ao obter métricas de visitantes');
      }
    } catch (error) {
      console.error('Erro ao obter métricas de visitantes:', error);
      throw error;
    }
  }
  
  // Obter métricas de conversão
  static async getConversionMetrics(startDate, endDate) {
    try {
      let url = `${API_BASE_URL}/analytics/conversions`;
      
      // Adicionar parâmetros de data se fornecidos
      if (startDate || endDate) {
        url += '?';
        if (startDate) url += `startDate=${startDate}`;
        if (startDate && endDate) url += '&';
        if (endDate) url += `endDate=${endDate}`;
      }
      
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${AuthService.getToken()}`
        }
      });
      
      const data = await response.json();
      
      if (response.ok) {
        return data.data;
      } else {
        throw new Error(data.error || 'Falha ao obter métricas de conversão');
      }
    } catch (error) {
      console.error('Erro ao obter métricas de conversão:', error);
      throw error;
    }
  }
}

// Classe para gerenciar candidatos
class CandidateService {
  // Obter lista de candidatos com paginação e filtros
  static async getCandidates(page = 1, limit = 10, filters = {}) {
    try {
      let url = `${API_BASE_URL}/candidates?page=${page}&limit=${limit}`;
      
      // Adicionar filtros à URL
      Object.keys(filters).forEach(key => {
        if (filters[key]) {
          url += `&${key}=${filters[key]}`;
        }
      });
      
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${AuthService.getToken()}`
        }
      });
      
      const data = await response.json();
      
      if (response.ok) {
        return data;
      } else {
        throw new Error(data.error || 'Falha ao obter candidatos');
      }
    } catch (error) {
      console.error('Erro ao obter candidatos:', error);
      throw error;
    }
  }
  
  // Obter um candidato específico
  static async getCandidate(id) {
    try {
      const response = await fetch(`${API_BASE_URL}/candidates/${id}`, {
        headers: {
          'Authorization': `Bearer ${AuthService.getToken()}`
        }
      });
      
      const data = await response.json();
      
      if (response.ok) {
        return data.data;
      } else {
        throw new Error(data.error || 'Falha ao obter candidato');
      }
    } catch (error) {
      console.error(`Erro ao obter candidato ${id}:`, error);
      throw error;
    }
  }
  
  // Atualizar status de um candidato
  static async updateCandidateStatus(id, status) {
    try {
      const response = await fetch(`${API_BASE_URL}/candidates/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${AuthService.getToken()}`
        },
        body: JSON.stringify({ status })
      });
      
      const data = await response.json();
      
      if (response.ok) {
        return data.data;
      } else {
        throw new Error(data.error || 'Falha ao atualizar candidato');
      }
    } catch (error) {
      console.error(`Erro ao atualizar candidato ${id}:`, error);
      throw error;
    }
  }
  
  // Obter estatísticas de candidatos
  static async getCandidateStats() {
    try {
      const response = await fetch(`${API_BASE_URL}/candidates/stats`, {
        headers: {
          'Authorization': `Bearer ${AuthService.getToken()}`
        }
      });
      
      const data = await response.json();
      
      if (response.ok) {
        return data.data;
      } else {
        throw new Error(data.error || 'Falha ao obter estatísticas de candidatos');
      }
    } catch (error) {
      console.error('Erro ao obter estatísticas de candidatos:', error);
      throw error;
    }
  }
  
  // Exportar candidatos para Excel/CSV
  static exportCandidates() {
    const token = AuthService.getToken();
    window.open(`${API_BASE_URL}/candidates/export?token=${token}`, '_blank');
  }
}

// Exportar serviços para uso no painel administrativo
export { AuthService, AnalyticsService, CandidateService };
