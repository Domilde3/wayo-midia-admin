// Script para integração da landing page com o Google Analytics e Facebook Pixel
// Este script deve ser incluído na landing page para integração com ferramentas externas

// Configuração do Google Analytics
function setupGoogleAnalytics(measurementId) {
  // Adicionar script do Google Analytics (GA4)
  const script = document.createElement('script');
  script.async = true;
  script.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`;
  document.head.appendChild(script);

  // Configurar o dataLayer e gtag
  window.dataLayer = window.dataLayer || [];
  function gtag() { dataLayer.push(arguments); }
  gtag('js', new Date());
  gtag('config', measurementId);

  // Expor gtag globalmente
  window.gtag = gtag;

  // Configurar eventos personalizados
  setupGAEvents();
}

// Configurar eventos personalizados do Google Analytics
function setupGAEvents() {
  // Rastrear cliques nos botões de candidatura
  document.querySelectorAll('a[href*="docs.google.com/forms"]').forEach(button => {
    button.addEventListener('click', (e) => {
      // Identificar qual vaga foi clicada
      const position = button.closest('.bg-black') ? 
        button.closest('.bg-black').querySelector('h3').textContent.trim() : 
        'Não identificada';
      
      // Enviar evento para o GA
      window.gtag('event', 'candidature_click', {
        'event_category': 'Engagement',
        'event_label': position
      });
    });
  });
}

// Configuração do Facebook Pixel
function setupFacebookPixel(pixelId) {
  // Adicionar script do Facebook Pixel
  !function(f,b,e,v,n,t,s) {
    if(f.fbq) return; n=f.fbq=function() {
      n.callMethod ? n.callMethod.apply(n,arguments) : n.queue.push(arguments)
    };
    if(!f._fbq) f._fbq=n; n.push=n; n.loaded=!0; n.version='2.0';
    n.queue=[]; t=b.createElement(e); t.async=!0;
    t.src=v; s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)
  }(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
  
  // Inicializar o Pixel
  fbq('init', pixelId);
  fbq('track', 'PageView');
  
  // Configurar eventos personalizados
  setupFBEvents();
}

// Configurar eventos personalizados do Facebook Pixel
function setupFBEvents() {
  // Rastrear cliques nos botões de candidatura
  document.querySelectorAll('a[href*="docs.google.com/forms"]').forEach(button => {
    button.addEventListener('click', (e) => {
      // Identificar qual vaga foi clicada
      const position = button.closest('.bg-black') ? 
        button.closest('.bg-black').querySelector('h3').textContent.trim() : 
        'Não identificada';
      
      // Enviar evento para o FB Pixel
      fbq('track', 'Lead', {
        content_name: position,
        content_category: 'Candidatura'
      });
    });
  });
}

// Inicializar integrações quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
  // Inicializar Google Analytics (substituir pelo ID real)
  setupGoogleAnalytics('G-XXXXXXXXXX');
  
  // Inicializar Facebook Pixel (substituir pelo ID real)
  setupFacebookPixel('XXXXXXXXXXXXXXXXXX');
  
  console.log('Integrações externas inicializadas');
});

// Exportar funções para uso global
window.WayoExternalIntegrations = {
  setupGoogleAnalytics,
  setupFacebookPixel
};
